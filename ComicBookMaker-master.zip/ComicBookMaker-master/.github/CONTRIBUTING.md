# Contributing to this Project

For pull requests to be merged, authors should:

* Write any applicable unit tests
* Add any relevant documentation
* Reference any relevant issues
* Obtain a review from a team member
