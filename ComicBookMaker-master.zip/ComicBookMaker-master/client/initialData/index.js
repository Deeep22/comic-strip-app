export { default as backgroundsArr } from './backgrounds';
export { default as charactersArr } from './characters';
export { default as bubblesArr } from './bubbles';
export { default as eyes } from './eyes';
export { default as people } from './people';
export { default as avatars } from './avatars';
export { default as stickers } from './stickers';
export { default as buildings } from './buildings';
