const bubblesArr = [
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/bubbles%2Fcomic-explosion-bubble-1.png?alt=media&token=03485df5-7cd1-4efe-9b21-1aa28db4bc79',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/bubbles%2Fcomic-explosion-bubble-2.png?alt=media&token=4b768dd3-9940-4648-93ca-720b2c361c75',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/bubbles%2Fcomic-explosion-bubble-3.png?alt=media&token=9577a826-58ea-4137-8d88-333245c28814',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/bubbles%2Fcomic-explosion-bubble-4.png?alt=media&token=3f901a1f-dde2-44cc-b402-ca9ff23b1a55',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/bubbles%2Fcomic-explosion-bubble-5-1024x676.png?alt=media&token=33a61338-d371-480a-aba8-c2633871183e',
  'https://sonny.js.org/react-komik/dist/chat_left.svg',
  'https://sonny.js.org/react-komik/dist/chat_right.svg',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/RandomComicBubbles%2F5a1bc30237ae64.1489022515117688342281.png?alt=media&token=b4cce147-92a1-4464-88d4-495dd583025a',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/RandomComicBubbles%2FUntitled%2011.16.16%20PM.svg?alt=media&token=e60c5ff7-3cc4-44da-aa56-75682b02070f',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/RandomComicBubbles%2FUntiddtled%20(2).svg?alt=media&token=fbfacc08-33dd-4ce5-8862-344afff6f225',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/RandomComicBubbles%2F12.svg?alt=media&token=36f1a486-e5b7-4d7a-92e0-7dd3425bfd02',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/RandomComicBubbles%2F13.svg?alt=media&token=74138a04-58d5-4f2d-89db-53216a53648e',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/RandomComicBubbles%2F14.svg?alt=media&token=72d9e52d-c1b8-473c-89f5-67dcfbee45f1'
];

export default bubblesArr;
