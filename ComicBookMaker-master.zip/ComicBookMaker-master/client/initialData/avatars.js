const avatars = [
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/avatar%2Favatar-1.svg?alt=media&token=0d8ff0fc-9ff6-4132-9e8d-a3c5b5156067',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/avatar%2Favatar-10.svg?alt=media&token=ea033067-9a92-4282-9d3b-af81e9d4b2a6',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/avatar%2Favatar-11.svg?alt=media&token=a61943ca-e618-4da3-ab43-7a7e6aec249f',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/avatar%2Favatar-12.svg?alt=media&token=be10263f-2c2b-4bfa-8b49-3a50709a9581',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/avatar%2Favatar-13.svg?alt=media&token=41195e24-ae7e-4982-9f0a-94934c941fc6',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/avatar%2Favatar-14.svg?alt=media&token=0ee6b08d-4624-4f3a-8f45-f50a5b40aab2',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/avatar%2Favatar-15.svg?alt=media&token=157485b3-cc89-4cf7-ab40-7bf4795e06f8',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/avatar%2Favatar-16.svg?alt=media&token=758d5ceb-6cb4-418b-896d-ccfad3c6c2be',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/avatar%2Favatar-17.svg?alt=media&token=f5d222c4-95f8-4c4b-ae37-75a397bb54eb',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/avatar%2Favatar-18.svg?alt=media&token=ecd5d253-40fd-4963-99c0-1958a8c236f7',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/avatar%2Favatar-19.svg?alt=media&token=09e379d3-d0cf-49e2-81b3-f9772d3a8cb9',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/avatar%2Favatar-20.svg?alt=media&token=5e12c190-d680-4691-837f-00e83b32a347',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/avatar%2Favatar-21.svg?alt=media&token=5c17cf6e-d5b7-4c1a-84ef-8b6853e0e7ed',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/avatar%2Favatar-22.svg?alt=media&token=e189ec8b-99c1-4d7e-bb9d-44ce382c2460',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/avatar%2Favatar-23.svg?alt=media&token=19fca654-c900-49de-b7e4-637fc57b6800',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/avatar%2Favatar-24.svg?alt=media&token=2e0268a0-7bd9-4b16-8832-178f8bbf38e0',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/avatar%2Favatar-25.svg?alt=media&token=b20c1aa8-4198-46f6-9089-40b4ec5c1a12'
];

export default avatars;
