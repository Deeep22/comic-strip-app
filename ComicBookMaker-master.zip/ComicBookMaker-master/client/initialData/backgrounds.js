const backgroundsArr = [
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/templates%2FMarvel%2FspidermanBack.svg?alt=media&token=2209dce7-1132-459f-af9d-a6ab98e51422',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/templates%2FBackground%2FPop-Art-Explosion.svg?alt=media&token=8952f1ef-261f-4a42-9352-3dea30a2398c',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/templates%2FBackground%2F13159.jpg?alt=media&token=42ca7025-3892-4edc-a069-8e86fbdc481f',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/templates%2FBackground%2F1540.jpg?alt=media&token=b870e07b-b4ba-4bf7-9436-66f92284f660',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/templates%2FBackground%2F4599.jpg?alt=media&token=6c4887b1-e223-4d87-9519-1022276c98b5',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/templates%2FBackground%2F11425.jpg?alt=media&token=a00f2a5a-f517-49bb-a932-9ca0100f04c1',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/Backgrounds%2F13302.jpg?alt=media&token=a50748a7-be91-4dc6-b422-c6dc742eb955',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/Backgrounds%2F13353.jpg?alt=media&token=f7ff46cd-d4c7-4a8f-a56e-9f146197c5f6',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/Backgrounds%2F13355.jpg?alt=media&token=fe18d28e-76a1-4d63-b2c9-f0a3c7b82df2',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/Backgrounds%2F8007.jpg?alt=media&token=d47ad681-460e-4c2c-8f53-8aa0239a90d2',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/Backgrounds%2F1421.jpg?alt=media&token=bd40ad8f-1b64-4bd8-abcb-e97553db65bd',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/Backgrounds%2F9595.jpg?alt=media&token=5beeb746-5d59-459a-9949-ca695a54af7d',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/Backgrounds%2F3.svg?alt=media&token=22fe64c0-8511-4e30-8d51-2a490a260619',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/Backgrounds%2F4.svg?alt=media&token=26c4b765-6a07-4105-b1c8-d5ea70348fa0',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/Backgrounds%2F8.svg?alt=media&token=478dd612-5a3b-4afb-9ac2-9a8e5f484b03',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/templates%2FBackground%2FBatmanBack.svg?alt=media&token=621f9d60-55c8-4cb8-b76e-42a4ae274b23'
];

export default backgroundsArr;
