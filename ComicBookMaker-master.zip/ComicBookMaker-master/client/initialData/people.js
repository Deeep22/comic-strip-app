const people = [
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/PeopleWorldWide%2Fafrican-1.svg?alt=media&token=cd8aeedc-b04b-493f-a293-2c3dd3ebf2fc',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/PeopleWorldWide%2Fafrican.svg?alt=media&token=2498ea4e-2eb2-447a-8811-4e10ccb67a5f',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/PeopleWorldWide%2FUntitled%20(1).svg?alt=media&token=55b0440c-416f-4aa3-a79b-1f29f63f61ce',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/PeopleWorldWide%2Fbrazilian-1.svg?alt=media&token=0c7d1e5c-a97a-4db3-8b90-ebb1562688eb',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/PeopleWorldWide%2Fbrazilian.svg?alt=media&token=b777b8e1-61e6-4a0b-81b8-7b472dcc9b8d',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/PeopleWorldWide%2FUntitled%20(2).svg?alt=media&token=42b94ece-fb7c-4fad-997f-3af682f474c5',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/PeopleWorldWide%2Findian-1.svg?alt=media&token=598a6709-c4b7-4947-a6b0-192ebb443868',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/PeopleWorldWide%2Findian.svg?alt=media&token=be49bc04-1aa6-434a-9334-e1f4b802acde',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/PeopleWorldWide%2FUntitled%20(3).svg?alt=media&token=4892911a-891a-4dc3-af1e-03901ca4369c',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/PeopleWorldWide%2Fitalian-1.svg?alt=media&token=0700be66-74d2-4861-9bbf-5c41ff344dd8',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/PeopleWorldWide%2Fitalian.svg?alt=media&token=2234a95b-e08e-4dc8-bcfe-ff92578230f6',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/PeopleWorldWide%2FUntitled%20(4).svg?alt=media&token=9b9853a2-a2d3-4ea7-a6d8-1e3dfb07df04',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/PeopleWorldWide%2Fkorean-1.svg?alt=media&token=19b13b4f-2726-493e-a0f3-3156c18d3069',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/PeopleWorldWide%2Fkorean.svg?alt=media&token=f6ead4dd-d648-4220-b96a-ce35613fd6d8',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/PeopleWorldWide%2FUntitled%20(5).svg?alt=media&token=a7f3027c-3766-4210-909a-dfd9cd5a646f',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/PeopleWorldWide%2Fvietnamese.svg?alt=media&token=ebdf7fc0-0c8c-4f1c-a881-af5a84d9cecc',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/PeopleWorldWide%2Fvietnamese-1.svg?alt=media&token=41661d16-2d83-4744-9e30-dde2ea1849e9',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/PeopleWorldWide%2FUntitled.svg?alt=media&token=c99d8dcf-76a9-4701-af80-aa7f0489b22e',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/PeopleWorldWide%2Frussian.svg?alt=media&token=f6b7387b-57d3-45ac-af9b-e17860a1a78b',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/PeopleWorldWide%2Frussian-1.svg?alt=media&token=e2db1917-6a85-43a9-a456-59733a5b115b',
  'https://sonny.js.org/react-komik/dist/char2.png',
  'https://sonny.js.org/react-komik/dist/char2_magic.png',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/templates%2FMarvel%2Fchar1.png?alt=media&token=3cd5f450-a772-4e03-b52e-ebde742ad7b4'
];

export default people;
