const stickers = [
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/RandomComicBubbles%2FUntitled%20(1).svg?alt=media&token=e4daa659-a4c6-47f0-8b13-7b259c4d4b95',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/RandomComicBubbles%2FUntitled%20(2).svg?alt=media&token=c22e999b-3347-4f11-a1fe-df2ee722db43',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/RandomComicBubbles%2FUntitled%20(3).svg?alt=media&token=365c39c8-6dfd-4457-92b6-95e3b61b79f5',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/RandomComicBubbles%2FUntitled.svg?alt=media&token=53f204de-6ceb-4568-8461-446c77c65264',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/RandomComicBubbles%2FUntitled%20(4).svg?alt=media&token=b020fc32-4092-401a-8404-7168204e9c44',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/RandomComicBubbles%2FUntitled%20(11).svg?alt=media&token=2c4603fd-712e-429c-8077-aa8af04a0aca',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/RandomComicBubbles%2F2.svg?alt=media&token=fd679549-5619-43bb-832f-d1f92b97bfe7',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/RandomComicBubbles%2F1.svg?alt=media&token=6b573af0-8381-4050-9524-e5de91132880'
];

export default stickers;
