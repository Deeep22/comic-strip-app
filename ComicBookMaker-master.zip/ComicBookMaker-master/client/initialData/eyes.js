const eyes = [
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/Eyes%2Fcartoon-eyes.svg?alt=media&token=70b8946d-1f82-4f94-8bf4-15ea4cbe01b6',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/Eyes%2Fcartoon-happy-eyes-1.svg?alt=media&token=04172336-4713-48ff-889c-427662fd27dd',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/Eyes%2Fcartoon-happy-eyes.svg?alt=media&token=3ffe74b5-d961-4156-8312-e4447b816ff6',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/Eyes%2Fcartoon-sad-eyes.svg?alt=media&token=1d65fffe-5218-40b7-a6de-d80dc85b8774',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/Eyes%2Ftired-cartoon-eyes.svg?alt=media&token=3b0d1236-f947-498e-b7c4-bdd844389824',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/Eyes%2Feye-1.svg?alt=media&token=505ec7b1-c2a4-48a6-9842-0f511643fa9b',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/Eyes%2Feye-with-reptilian-pupil.svg?alt=media&token=a5742302-44b6-4768-9547-60f45dc3b438',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/Eyes%2Ffemale-eye.svg?alt=media&token=ace70445-2d0d-4066-badd-1087467ba6c6',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/Eyes%2Feye-11.svg?alt=media&token=e6c236c9-f263-4591-a60a-8ff8346b506b',
  'https://firebasestorage.googleapis.com/v0/b/exquisite-comics.appspot.com/o/Eyes%2Feye-with-eyelash.svg?alt=media&token=f7767780-8111-42eb-9ffc-08f3ab1fcd9b'
];

export default eyes;
